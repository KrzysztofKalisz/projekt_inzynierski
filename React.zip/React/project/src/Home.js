const Home = () => {
    return (  
    <div className="home">
        <h2>Homepage</h2>
    </div>
    );
}
 
export default Home;